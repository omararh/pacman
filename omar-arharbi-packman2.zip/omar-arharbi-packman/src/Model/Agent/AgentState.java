package Model.Agent;

public enum AgentState {
    ALIVE, DEAD, SCARED
}
