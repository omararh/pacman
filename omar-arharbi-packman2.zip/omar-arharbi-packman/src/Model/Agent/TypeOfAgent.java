package Model.Agent;

public enum TypeOfAgent {
    PACMAN, GHOST
}
