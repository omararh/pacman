package Model.Game;

public enum GameState {
    START, RUN, GAME_OVER, VICTORY
}